
import { _decorator, Color, Component, Graphics, Node, RichText, UITransform } from 'cc';
import { Context, Script } from 'vm';
 
const { ccclass, property } = _decorator;
 
 

 export class CustomMeshData {
   public vc:number=0;
   public ic:number=0;
   public stride:number=0;
   public vData:Float32Array=new Float32Array
   public iData:Uint16Array = new Uint16Array
   public indexStart:number=0;

   public constructor(vc:number,ic:number,stride:number,vData:Float32Array,iData:Uint16Array,indexStart:number) {
    this.iData=iData;
    this.ic=ic;
    this.vc=vc;
    this.stride=stride;
    this.vData=vData;
    this.indexStart=indexStart

   }

}
 
   
 
   
@ccclass('CucutaTestBase')
export class CucutaTestBase extends Component {

    public getInstance(param:string)  {
        let tstFuncs: string[] = []
        let protoOfTest:Object = Object.getPrototypeOf(this);
        let objs = Object.getOwnPropertyNames(protoOfTest);  
        objs.forEach(t=> {
            if(t.split("_").pop()=="Test") {
                 let fun = t
                tstFuncs.push(fun)
            }
        }) 
        return tstFuncs
    }
}


