import { SceneUndoManager } from './scene';
declare const previewUndoManager: SceneUndoManager;
export default previewUndoManager;
//# sourceMappingURL=preview.d.ts.map