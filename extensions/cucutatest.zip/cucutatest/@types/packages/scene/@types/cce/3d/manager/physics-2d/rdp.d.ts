export = RDP;
declare function RDP(points: any, epsilon: any): any;
//# sourceMappingURL=rdp.d.ts.map