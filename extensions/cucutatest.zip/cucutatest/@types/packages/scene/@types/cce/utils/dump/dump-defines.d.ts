import { DumpInterface } from './types/dump-interface';
declare const DumpDefines: {
    [key: string]: DumpInterface;
};
export { DumpDefines };
//# sourceMappingURL=dump-defines.d.ts.map