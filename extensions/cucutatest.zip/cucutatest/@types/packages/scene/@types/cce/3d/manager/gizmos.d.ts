import gizmo from '../../public/gizmos';
export default gizmo;
//# sourceMappingURL=gizmos.d.ts.map