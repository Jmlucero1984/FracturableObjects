import { Component } from 'cc';
export declare class ControllerShapeCollider extends Component {
    isDetectMesh: boolean;
    isRender: boolean;
    onLoad(): void;
}
//# sourceMappingURL=controller-shape-collider.d.ts.map