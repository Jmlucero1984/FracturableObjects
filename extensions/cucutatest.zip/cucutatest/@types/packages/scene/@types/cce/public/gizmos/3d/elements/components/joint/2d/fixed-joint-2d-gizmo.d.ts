import Joint2DGizmo from './joint-2d-gizmo';
declare class FixedJoint2DGizmo extends Joint2DGizmo {
}
export default FixedJoint2DGizmo;
//# sourceMappingURL=fixed-joint-2d-gizmo.d.ts.map