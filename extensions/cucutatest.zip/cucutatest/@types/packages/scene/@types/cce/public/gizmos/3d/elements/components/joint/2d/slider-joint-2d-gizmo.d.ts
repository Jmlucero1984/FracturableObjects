import Joint2DGizmo from './joint-2d-gizmo';
declare class SliderJoint2DGizmo extends Joint2DGizmo {
}
export default SliderJoint2DGizmo;
//# sourceMappingURL=slider-joint-2d-gizmo.d.ts.map