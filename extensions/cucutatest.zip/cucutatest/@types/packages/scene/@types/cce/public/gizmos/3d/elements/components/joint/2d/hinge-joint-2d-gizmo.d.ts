import Joint2DGizmo from './joint-2d-gizmo';
declare class HingeJoint2DGizmo extends Joint2DGizmo {
}
export default HingeJoint2DGizmo;
//# sourceMappingURL=hinge-joint-2d-gizmo.d.ts.map