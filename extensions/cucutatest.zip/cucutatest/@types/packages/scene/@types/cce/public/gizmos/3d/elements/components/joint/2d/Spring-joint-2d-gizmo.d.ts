import Joint2DGizmo from './joint-2d-gizmo';
declare class SpringJoint2DGizmo extends Joint2DGizmo {
}
export default SpringJoint2DGizmo;
//# sourceMappingURL=Spring-joint-2d-gizmo.d.ts.map