declare function check(): void;
declare global {
    export let AppModulePath: string;
}
export { check };
//# sourceMappingURL=preload.d.ts.map