declare const ipc: any;
export default ipc;
//# sourceMappingURL=index.d.ts.map