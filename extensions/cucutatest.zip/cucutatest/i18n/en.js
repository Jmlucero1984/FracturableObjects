"use strict";
module.exports={
    open_panel:"CucutaTest",
    send_to_panel:"Opening CucutaTest",
    description:"Naive Testing Framework"};